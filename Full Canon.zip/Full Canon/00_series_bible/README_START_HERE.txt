LAUNCH WINDOW ZERO — COMPLETE WORLD BIBLE (WORKING CANON)

How to use this folder
- When prompting an AI to write or revise a chapter, include:
  1) 00_series_bible/book_tone.txt
  2) 00_series_bible/writing_rules.txt
  3) Any relevant world files (fold_physics, coalition_politics, etc.)
  4) The character files for POV and scene participants
  5) The chapter worksheet file for the chapter you are writing

Naming conventions
- Earth Havens are H-01 through H-12.
- Off-world biomes are Selene (Luna) and Ares Reach (Mars).

Non-negotiables
- The universe responds structurally, not morally.
- No villain empire. No heroic override of physical law.
- Humor is human, dry, and situational. The universe is never the joke.
